# -*- coding: utf-8 -*-
"""
Created on Fri Oct 19 04:28:22 2018

@author: hwpar5
"""

import unittest
import testings_spanish_level_real
import pandas

class TestSpanishLevel(unittest.TestCase):
    
    def test_corpusMake(self):
        testings_spanish_level_real.corpusMake(10)
        with open('corpusdata.txt','r') as f:
            doc = f.readlines()
        self.assertEqual(len(doc), 11)
        self.assertNotEqual(len(doc), 12)
        self.assertNotEqual(len(doc), 10)
        
    def test_dataset_prep(self):
        data = testings_spanish_level_real.dataset_prep()
        self.assertEqual(len(data), 11)
        self.assertNotEqual(len(data), 12)
        self.assertNotEqual(len(data), 10)
        
    def test_nlp_features(self):
        trainDF = pandas.DataFrame()
        target_data = [0, 1, 2, 3]
        texts = ["In a universe", "There are five types of people", "One of them which never cease to hunger", "The other dies"]
        trainDF['label'] = target_data
        trainDF['text'] = texts
        data = testings_spanish_level_real.nlp_features(trainDF)
        self.assertEqual(data['char_count'][0], 13)
        self.assertEqual(data['char_count'][1], 30)
        self.assertNotEqual(data['char_count'][2], 13)
        self.assertNotEqual(data['char_count'][3], 13)
        
        self.assertEqual(data['word_count'][0], 3)
        self.assertEqual(data['word_count'][1], 6)
        self.assertNotEqual(data['word_count'][2], 13)
        self.assertNotEqual(data['word_count'][3], 13)
        
        self.assertEqual(data['word_density'][0], 3.25)
        self.assertEqual(data['word_density'][1], 4.285714285714286)
        self.assertNotEqual(data['word_density'][2], 13)
        self.assertNotEqual(data['word_density'][3], 13)
        
        self.assertEqual(data['punctuation_count'][0], 0)
        self.assertEqual(data['punctuation_count'][1], 0)
        self.assertNotEqual(data['punctuation_count'][2], 13)
        self.assertNotEqual(data['punctuation_count'][3], 13)
        
        self.assertEqual(data['title_word_count'][0], 1)
        self.assertEqual(data['title_word_count'][1], 1)
        self.assertNotEqual(data['title_word_count'][2], 13)
        self.assertNotEqual(data['title_word_count'][3], 13)
        
        self.assertEqual(data['upper_case_word_count'][0], 0)
        self.assertEqual(data['upper_case_word_count'][1], 0)
        self.assertNotEqual(data['upper_case_word_count'][2], 13)
        self.assertNotEqual(data['upper_case_word_count'][3], 13)
    
    def test_split_section(self):
        trainDF = pandas.DataFrame()
        target_data = [0, 1, 2, 3]
        texts = ["In a universe", "There are five types of people", "One of them which never cease to hunger", "The other dies"]
        trainDF['label'] = target_data
        trainDF['text'] = texts
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 0)
        self.assertEqual(len(train_x), 3)
        self.assertEqual(len(valid_x), 1)
        self.assertEqual(len(train_y), 3)
        self.assertEqual(len(valid_y), 1)
        
    def test_count_vector(self):
        trainDF = pandas.DataFrame()
        target_data = [0, 1, 2, 3]
        texts = ["In a universe", "There are five types of people", "One of them which never cease to hunger", "The other dies"]
        trainDF['label'] = target_data
        trainDF['text'] = texts
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 0)
        accuracy, accuracy1, accuracy2, accuracy3, accuracy4 = testings_spanish_level_real.count_vector(train_x, valid_x, train_y, valid_y, trainDF)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        self.assertTrue(0 <= accuracy4 <= 1)
        
    def test_tfidf_vectors(self):
        trainDF = pandas.DataFrame()
        target_data = [0, 1, 2, 3]
        texts = ["In a universe", "There are five types of people", "One of them which never cease to hunger", "The other dies"]
        trainDF['label'] = target_data
        trainDF['text'] = texts
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 0)
        accuracy, accuracy1, accuracy2, accuracy3, accuracy4, accuracy5, accuracy6, accuracy7, accuracy8, accuracy9 = testings_spanish_level_real.tf_idf_vectors(train_x, valid_x, train_y, valid_y, trainDF)    

        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        self.assertTrue(0 <= accuracy4 <= 1)
        self.assertTrue(0 <= accuracy5 <= 1)
        self.assertTrue(0 <= accuracy6 <= 1)
        self.assertTrue(0 <= accuracy7 <= 1)
        self.assertTrue(0 <= accuracy8 <= 1)
        self.assertTrue(0 <= accuracy9 <= 1)
        
    def test_nlp_train(self):
        trainDF = pandas.DataFrame()
        target_data = [0, 1, 2, 3]
        texts = ["In a universe", "There are five types of people", "One of them which never cease to hunger", "The other dies"]
        trainDF['label'] = target_data
        trainDF['text'] = texts
        trainDF = testings_spanish_level_real.nlp_features(trainDF)
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 1)
        accuracy, accuracy1, accuracy2, accuracy3 = testings_spanish_level_real.nlp_train(train_x, valid_x, train_y, valid_y)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 2)
        accuracy, accuracy1, accuracy2, accuracy3 = testings_spanish_level_real.nlp_train(train_x, valid_x, train_y, valid_y)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 3)
        accuracy, accuracy1, accuracy2, accuracy3 = testings_spanish_level_real.nlp_train(train_x, valid_x, train_y, valid_y)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 4)
        accuracy, accuracy1, accuracy2, accuracy3 = testings_spanish_level_real.nlp_train(train_x, valid_x, train_y, valid_y)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 5)
        accuracy, accuracy1, accuracy2, accuracy3 = testings_spanish_level_real.nlp_train(train_x, valid_x, train_y, valid_y)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        
        train_x, valid_x, train_y, valid_y = testings_spanish_level_real.split_section(trainDF, 6)
        accuracy, accuracy1, accuracy2, accuracy3 = testings_spanish_level_real.nlp_train(train_x, valid_x, train_y, valid_y)
        
        self.assertTrue(0 <= accuracy <= 1)
        self.assertTrue(0 <= accuracy1 <= 1)
        self.assertTrue(0 <= accuracy2 <= 1)
        self.assertTrue(0 <= accuracy3 <= 1)
        
if __name__ == "__main__":
    unittest.main()