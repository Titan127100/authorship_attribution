# -*- coding: utf-8 -*-
"""
Created on Fri Oct 19 04:28:22 2018

@author: hwpar5
"""

import unittest
import feature_testings_10_authors_real
import pandas

class TestSpanishLevel(unittest.TestCase):
    
    def test_corpusMake(self):
        feature_testings_10_authors_real.corpusMake(10)
        with open('corpusdata.txt','r') as f:
            doc = f.readlines()
        self.assertEqual(len(doc), 90)
        self.assertNotEqual(len(doc), 91)
        self.assertNotEqual(len(doc), 89)
        
    def test_loadData(self):
        doc, target_data = feature_testings_10_authors_real.loadData()
        self.assertEqual(len(doc), 90)
        self.assertNotEqual(len(doc), 91)
        self.assertNotEqual(len(doc), 89)
        
    def test_count_vector(self):
        texts = ["a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a"]
        target_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        data = feature_testings_10_authors_real.count_vector(texts, target_data)
        
        self.assertEqual(len(data), 20)
        self.assertNotEqual(len(data), 21)
        self.assertNotEqual(len(data), 19)
    
    def test_cross_validation(self):
        texts = ["a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a"]
        target_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        X_data, Y_data = feature_testings_10_authors_real.cross_validation_split(texts, target_data, 10)
        self.assertEqual(len(X_data), 10)
        self.assertNotEqual(len(X_data), 11)
        self.assertNotEqual(len(X_data), 9)
        self.assertEqual(len(Y_data), 10)
        self.assertNotEqual(len(Y_data), 11)
        self.assertNotEqual(len(Y_data), 9)
        
    def test_run_machine_learning(self):
        texts = ["a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a", "a"]
        target_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        xtrain_count = feature_testings_10_authors_real.count_vector(texts, target_data)
        X_data, Y_data = feature_testings_10_authors_real.cross_validation_split(xtrain_count, target_data, 10)
        test_score, test_score1, test_score2, test_score3, test_score4, test_score5, test_score6, test_score7, test_score8, test_score9 = feature_testings_10_authors_real.run_machine_learning(X_data, Y_data, 10)

        self.assertTrue(0 <= test_score <= 1)
        self.assertTrue(0 <= test_score1 <= 1)
        self.assertTrue(0 <= test_score2 <= 1)
        self.assertTrue(0 <= test_score3 <= 1)
        self.assertTrue(0 <= test_score4 <= 1)
        self.assertTrue(0 <= test_score5 <= 1)
        self.assertTrue(0 <= test_score6 <= 1)
        self.assertTrue(0 <= test_score7 <= 1)
        self.assertTrue(0 <= test_score8 <= 1)
        self.assertTrue(0 <= test_score9 <= 1)
    
if __name__ == "__main__":
    unittest.main()